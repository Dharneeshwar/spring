package com.cg.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Customer;
import com.cg.beans.Wallet;
import com.cg.repo.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	Wallet wallet;
	
	@Autowired
	Customer customer;
	
	@Override
	public Customer create(Customer customer) {
	
		Wallet wallet = new Wallet();
		wallet.setBalance(0);
		
		customer.setWallet(wallet);
		
		return customerRepository.save(customer);
	}

	@Override
	public double showBalance(int customerId) {
		
		return customerRepository.findById(customerId).get().getWallet().getBalance();
	}

	@Override
	public boolean fundTransfer(String sourceMobile, String TargetMobile, BigDecimal amount) {
		
		double amountBal =  amount.doubleValue();
		if(customerRepository.findByMobileNo(sourceMobile).getWallet().getBalance() < amountBal) {
			return false;
		}
		else {
			Customer senderCustomer = customerRepository.findByMobileNo(sourceMobile);
			Customer recieverCustomer = customerRepository.findByMobileNo(TargetMobile);
			
			Wallet senderWallet = senderCustomer.getWallet();
			double sendbal = senderWallet.getBalance();
			sendbal = sendbal - amountBal;
			senderWallet.setBalance(sendbal);
			senderCustomer.setWallet(senderWallet);
			
			Wallet reciverWallet = recieverCustomer.getWallet();
			double recbal = reciverWallet.getBalance(); 
			recbal = recbal + amountBal;
			reciverWallet.setBalance(recbal);
			recieverCustomer.setWallet(reciverWallet);
			
			customerRepository.save(senderCustomer);
			
			customerRepository.save(recieverCustomer);
			return true;
		}
		
		
	}

	@Override
	public boolean deposit(int custid, double amount) {
	
		customer = customerRepository.findById(custid).get();
		
		wallet = customer.getWallet();
		
		double newBalance = wallet.getBalance()+ amount;
		wallet.setBalance(newBalance);
		customer.setWallet(wallet);
		
		customerRepository.save(customer);
		return true;
	}

	@Override
	public boolean withDraw(int custid, double amount) {
		
		if(customerRepository.findById(custid).get().getWallet().getBalance()<amount) {
			return false;
		}
		else {
			customer = customerRepository.findById(custid).get();
			
			wallet = customer.getWallet();
			
			double newBalance = wallet.getBalance() - amount;
			wallet.setBalance(newBalance);
			customer.setWallet(wallet);
			
			customerRepository.save(customer);
			return true;
			
		}
	}

}
