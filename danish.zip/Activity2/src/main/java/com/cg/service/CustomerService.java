package com.cg.service;

import java.math.BigDecimal;

import com.cg.beans.Customer;

public interface CustomerService {

	
	public Customer create(Customer customer);
	
	public double showBalance(int customerId);
	
	public boolean fundTransfer(String sourceMobile,String TargetMobile,BigDecimal amount);
	
	public boolean deposit(int custid,double amount);
	
	public boolean withDraw(int custid,double amount);
}
