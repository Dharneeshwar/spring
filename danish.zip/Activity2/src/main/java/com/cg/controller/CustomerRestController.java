package com.cg.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Customer;
import com.cg.service.CustomerService;

@RestController
public class CustomerRestController {

	@Autowired
	CustomerService customerService;
	
	@PostMapping("/create")
	public Customer createCustomer(@RequestBody Customer customer) {
		return customerService.create(customer);
	}
	
	@GetMapping("/showbalance/{customerId}")
	public double getBalance(@PathVariable Integer customerId) {
		return customerService.showBalance(customerId);
	}
	
	@PostMapping("/deposit/{customerId}/{amount}")
	public boolean deposit(@PathVariable Integer customerId,@PathVariable Double amount) {
		return customerService.deposit(customerId, amount);
	}
	
	@PostMapping("/withdraw/{customerId}/{amount}")
	public boolean withDraw(@PathVariable Integer customerId,@PathVariable Double amount) {
		return customerService.withDraw(customerId, amount);
	}
	
	@PostMapping("/ft/{sendermobile}/{recievermobile}/{amount}")
	public boolean fundTransfer(@PathVariable String sendermobile,@PathVariable String recievermobile,@PathVariable String amount) {
		return customerService.fundTransfer(sendermobile, recievermobile, new BigDecimal(amount));
	}
	
}
